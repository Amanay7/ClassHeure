package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors (Original Academic Navy & Pure/Soft Clean Palette)
val NavyPrimary = Color(0xFF1E3A8A) // Original Deep Academic Navy Blue
val NavyDark = Color(0xFF172554)
val NavyLight = Color(0xFFDBEAFE)
val GoldAccent = Color(0xFFD97706)
val OffWhite = Color(0xFFF8FAFC) // Clean modern academic background (Light slate / crisp off-white)
val SlateGray = Color(0xFF64748B)
val Charcoal = Color(0xFF0F172A)

// Dark Theme Colors (Premium Academic Midnight Navy)
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF161F38)
val DarkPrimary = Color(0xFF5C7CFA)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkPrimaryContainer = Color(0xFF253154)
val DarkOnPrimaryContainer = Color(0xFFDDE4FF)
val DarkSurfaceVariant = Color(0xFF1E294B)
val DarkOutline = Color(0xFF475569)

// Emerald Theme Colors (Classy Library Green)
val EmeraldPrimary = Color(0xFF1E5E3A)
val EmeraldBackground = Color(0xFFF4F9F5)
val EmeraldSurface = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFD8F3DC)
val EmeraldOnPrimaryContainer = Color(0xFF113821)
val EmeraldTextPrimary = Color(0xFF0F2419)
val EmeraldTextSecondary = Color(0xFF406B53)

// Amethyst Theme Colors (Modern Royal Purple)
val AmethystBackground = Color(0xFF0E0B1E)
val AmethystSurface = Color(0xFF191332)
val AmethystPrimary = Color(0xFFC084FC)
val AmethystTextPrimary = Color(0xFFF3E8FF)
val AmethystTextSecondary = Color(0xFFA78BFA)
val AmethystPrimaryContainer = Color(0xFF3B0764)
val AmethystOnPrimaryContainer = Color(0xFFE8D5FF)
val AmethystSurfaceVariant = Color(0xFF251C44)
val AmethystOutline = Color(0xFF5B4B8A)
