package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

// Polices Google Fonts installées localement
val LoraFontFamily = FontFamily(
    Font(R.font.lora, FontWeight.Normal)
)

val AlmaraiFontFamily = FontFamily(
    Font(R.font.almarai, FontWeight.Normal)
)

val TajawalFontFamily = FontFamily(
    Font(R.font.tajawal, FontWeight.Normal)
)

val CairoFontFamily = FontFamily(
    Font(R.font.cairo, FontWeight.Normal)
)

val AmiriFontFamily = FontFamily(
    Font(R.font.amiri, FontWeight.Normal)
)

val NotoNastaliqUrduFontFamily = FontFamily(
    Font(R.font.noto_nastaliq_urdu, FontWeight.Normal)
)

val DancingScriptFontFamily = FontFamily(
    Font(R.font.dancing_script, FontWeight.Normal)
)

val GreatVibesFontFamily = FontFamily(
    Font(R.font.great_vibes, FontWeight.Normal)
)

val DiwaniFontFamily = FontFamily(
    Font(R.font.diwani, FontWeight.Normal)
)

fun getFontFamilyByName(name: String, activeLanguage: String = "fr"): FontFamily {
    if (activeLanguage == "ar") {
        return when (name) {
            "Tajawal" -> TajawalFontFamily
            "Almarai" -> AlmaraiFontFamily
            else -> AlmaraiFontFamily // Almarai par défaut pour l'arabe
        }
    }
    return when (name) {
        "Times New Roman" -> FontFamily.Serif
        "Lora" -> LoraFontFamily
        else -> FontFamily.Serif // Times New Roman par défaut
    }
}

// Structure pour les palettes de couleurs personnalisées du thème
data class ThemePalette(
    val key: String,
    val label: String,
    val primaryLight: Color,
    val primaryContainerLight: Color,
    val primaryDark: Color,
    val primaryContainerDark: Color,
    val previewColor: Color
)

val AppThemePalettes = listOf(
    ThemePalette(
        key = "default",
        label = "Marine",
        primaryLight = Color(0xFF1E3A8A),
        primaryContainerLight = Color(0xFFDBEAFE),
        primaryDark = Color(0xFF5C7CFA),
        primaryContainerDark = Color(0xFF253154),
        previewColor = Color(0xFF1E3A8A)
    ),
    ThemePalette(
        key = "emerald",
        label = "Émeraude",
        primaryLight = Color(0xFF065F46),
        primaryContainerLight = Color(0xFFD1FAE5),
        primaryDark = Color(0xFF34D399),
        primaryContainerDark = Color(0xFF064E3B),
        previewColor = Color(0xFF059669)
    ),
    ThemePalette(
        key = "indigo",
        label = "Indigo",
        primaryLight = Color(0xFF3730A3),
        primaryContainerLight = Color(0xFFE0E7FF),
        primaryDark = Color(0xFF818CF8),
        primaryContainerDark = Color(0xFF312E81),
        previewColor = Color(0xFF4F46E5)
    ),
    ThemePalette(
        key = "purple",
        label = "Pourpre",
        primaryLight = Color(0xFF6B21A8),
        primaryContainerLight = Color(0xFFF3E8FF),
        primaryDark = Color(0xFFA855F7),
        primaryContainerDark = Color(0xFF581C87),
        previewColor = Color(0xFF7C3AED)
    ),
    ThemePalette(
        key = "amber",
        label = "Ambre",
        primaryLight = Color(0xFFB45309),
        primaryContainerLight = Color(0xFFFEF3C7),
        primaryDark = Color(0xFFFBBF24),
        primaryContainerDark = Color(0xFF78350F),
        previewColor = Color(0xFFD97706)
    ),
    ThemePalette(
        key = "teal",
        label = "Canard",
        primaryLight = Color(0xFF0F766E),
        primaryContainerLight = Color(0xFFCCFBF1),
        primaryDark = Color(0xFF2DD4BF),
        primaryContainerDark = Color(0xFF134E4A),
        previewColor = Color(0xFF0D9488)
    ),
    ThemePalette(
        key = "rose",
        label = "Bordeaux",
        primaryLight = Color(0xFF9F1239),
        primaryContainerLight = Color(0xFFFFE4E6),
        primaryDark = Color(0xFFFB7185),
        primaryContainerDark = Color(0xFF881337),
        previewColor = Color(0xFFE11D48)
    ),
    ThemePalette(
        key = "slate",
        label = "Ardoise",
        primaryLight = Color(0xFF334155),
        primaryContainerLight = Color(0xFFE2E8F0),
        primaryDark = Color(0xFF94A3B8),
        primaryContainerDark = Color(0xFF1E293B),
        previewColor = Color(0xFF475569)
    )
)

// Thème académique bleu marine et blanc cassé pour la journée
private val LightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    primaryContainer = NavyLight,
    onPrimaryContainer = NavyPrimary,
    secondary = SlateGray,
    onSecondary = Color.White,
    background = OffWhite,
    onBackground = Charcoal,
    surface = Color.White,
    onSurface = Charcoal,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFFE2E8F0),
    tertiary = GoldAccent,
    onTertiary = Color.White
)

// Thème académique sobre pour la nuit
private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = Color.White,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = SlateGray,
    onSecondary = DarkTextPrimary,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkOutline,
    tertiary = GoldAccent,
    onTertiary = Charcoal
)

// Thème Améthyste (Violet moderne d'inspiration royale)
private val AmethystColorScheme = darkColorScheme(
    primary = AmethystPrimary,
    onPrimary = AmethystPrimaryContainer,
    primaryContainer = AmethystPrimaryContainer,
    onPrimaryContainer = AmethystOnPrimaryContainer,
    secondary = AmethystTextSecondary,
    onSecondary = AmethystTextPrimary,
    background = AmethystBackground,
    onBackground = AmethystTextPrimary,
    surface = AmethystSurface,
    onSurface = AmethystTextPrimary,
    surfaceVariant = AmethystSurfaceVariant,
    onSurfaceVariant = AmethystTextSecondary,
    outline = AmethystOutline,
    tertiary = GoldAccent,
    onTertiary = Charcoal
)

@Composable
fun MyApplicationTheme(
    themeName: String = "system",
    fontFamilyName: String = "Times New Roman",
    fontSizeScaleName: String = "small",
    isFontBold: Boolean = false,
    themeColor: String = "default",
    activeLanguage: String = "fr",
    content: @Composable () -> Unit
) {
    val activePalette = AppThemePalettes.find { it.key == themeColor } ?: AppThemePalettes.first()

    // Sélection du jeu de couleurs avec prise en compte de la palette personnalisée
    val isSystemDark = isSystemInDarkTheme()
    val baseScheme = when (themeName) {
        "light" -> LightColorScheme.copy(
            primary = activePalette.primaryLight,
            primaryContainer = activePalette.primaryContainerLight,
            onPrimaryContainer = activePalette.primaryLight
        )
        "dark" -> DarkColorScheme.copy(
            primary = activePalette.primaryDark,
            primaryContainer = activePalette.primaryContainerDark,
            onPrimaryContainer = Color.White
        )
        "amethyst" -> AmethystColorScheme
        else -> if (isSystemDark) {
            DarkColorScheme.copy(
                primary = activePalette.primaryDark,
                primaryContainer = activePalette.primaryContainerDark,
                onPrimaryContainer = Color.White
            )
        } else {
            LightColorScheme.copy(
                primary = activePalette.primaryLight,
                primaryContainer = activePalette.primaryContainerLight,
                onPrimaryContainer = activePalette.primaryLight
            )
        }
    }

    val isArabic = activeLanguage == "ar"

    // Résolution de la police choisie par l'utilisateur
    val fontFamily = getFontFamilyByName(fontFamilyName, activeLanguage)

    // Calcul de l'échelle de taille de texte (En français, "petit" par défaut : 0.85f ; +12% pour l'arabe afin d'assurer une excellente lisibilité)
    val effectiveScaleName = if (!isArabic && (fontSizeScaleName == "small" || fontSizeScaleName.isBlank())) {
        "small"
    } else {
        fontSizeScaleName
    }
    val baseMultiplier = when (effectiveScaleName) {
        "small" -> 0.85f
        "large" -> 1.2f
        else -> 1.0f // "medium"
    }
    val multiplier = if (isArabic) baseMultiplier * 1.12f else baseMultiplier
    // Facteur d'interligne (1.6 - 1.8x) pour les voyelles et diacritiques arabes
    val lineMultiplier = if (isArabic) 1.25f else 1.0f

    // Poids de police selon l'option utilisateur (Normal par défaut, Gras si activé)
    val displayWeight = if (isFontBold) FontWeight.Bold else FontWeight.Normal
    val headlineWeight = if (isFontBold) FontWeight.Bold else FontWeight.Normal
    val titleWeight = if (isFontBold) FontWeight.Bold else FontWeight.Normal
    val bodyWeight = if (isFontBold) FontWeight.Bold else FontWeight.Normal
    val labelWeight = if (isFontBold) FontWeight.Bold else FontWeight.Normal

    // Application stricte de la police et du poids choisi à l'ENSEMBLE des styles typographiques Material 3
    val customTypography = Typography(
        displayLarge = TextStyle(
            fontFamily = fontFamily,
            fontWeight = displayWeight,
            fontSize = (57 * multiplier).sp,
            lineHeight = (64 * multiplier * lineMultiplier).sp
        ),
        displayMedium = TextStyle(
            fontFamily = fontFamily,
            fontWeight = displayWeight,
            fontSize = (45 * multiplier).sp,
            lineHeight = (52 * multiplier * lineMultiplier).sp
        ),
        displaySmall = TextStyle(
            fontFamily = fontFamily,
            fontWeight = displayWeight,
            fontSize = (36 * multiplier).sp,
            lineHeight = (44 * multiplier * lineMultiplier).sp
        ),
        headlineLarge = TextStyle(
            fontFamily = fontFamily,
            fontWeight = headlineWeight,
            fontSize = (32 * multiplier).sp,
            lineHeight = (40 * multiplier * lineMultiplier).sp
        ),
        headlineMedium = TextStyle(
            fontFamily = fontFamily,
            fontWeight = headlineWeight,
            fontSize = (28 * multiplier).sp,
            lineHeight = (36 * multiplier * lineMultiplier).sp
        ),
        headlineSmall = TextStyle(
            fontFamily = fontFamily,
            fontWeight = headlineWeight,
            fontSize = (24 * multiplier).sp,
            lineHeight = (32 * multiplier * lineMultiplier).sp
        ),
        titleLarge = TextStyle(
            fontFamily = fontFamily,
            fontWeight = titleWeight,
            fontSize = (22 * multiplier).sp,
            lineHeight = (28 * multiplier * lineMultiplier).sp
        ),
        titleMedium = TextStyle(
            fontFamily = fontFamily,
            fontWeight = titleWeight,
            fontSize = (16 * multiplier).sp,
            lineHeight = (24 * multiplier * lineMultiplier).sp
        ),
        titleSmall = TextStyle(
            fontFamily = fontFamily,
            fontWeight = titleWeight,
            fontSize = (14 * multiplier).sp,
            lineHeight = (20 * multiplier * lineMultiplier).sp
        ),
        bodyLarge = TextStyle(
            fontFamily = fontFamily,
            fontWeight = bodyWeight,
            fontSize = (16 * multiplier).sp,
            lineHeight = (24 * multiplier * lineMultiplier).sp,
            letterSpacing = if (isArabic) 0.sp else 0.5.sp
        ),
        bodyMedium = TextStyle(
            fontFamily = fontFamily,
            fontWeight = bodyWeight,
            fontSize = (14 * multiplier).sp,
            lineHeight = (20 * multiplier * lineMultiplier).sp
        ),
        bodySmall = TextStyle(
            fontFamily = fontFamily,
            fontWeight = bodyWeight,
            fontSize = (12 * multiplier).sp,
            lineHeight = (16 * multiplier * lineMultiplier).sp
        ),
        labelLarge = TextStyle(
            fontFamily = fontFamily,
            fontWeight = labelWeight,
            fontSize = (14 * multiplier).sp,
            lineHeight = (20 * multiplier * lineMultiplier).sp
        ),
        labelMedium = TextStyle(
            fontFamily = fontFamily,
            fontWeight = labelWeight,
            fontSize = (12 * multiplier).sp,
            lineHeight = (16 * multiplier * lineMultiplier).sp
        ),
        labelSmall = TextStyle(
            fontFamily = fontFamily,
            fontWeight = labelWeight,
            fontSize = (11 * multiplier).sp,
            lineHeight = (16 * multiplier * lineMultiplier).sp
        )
    )

    MaterialTheme(
        colorScheme = baseScheme,
        typography = customTypography,
        content = content
    )
}
